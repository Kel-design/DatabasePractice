package com.cupitmadland.abcinc.myinterface;

import java.util.List;



import com.cupitmadland.abcinc.model.Order;

public interface OrderDAO {
	
	List<Order> getAllOrders();
}
