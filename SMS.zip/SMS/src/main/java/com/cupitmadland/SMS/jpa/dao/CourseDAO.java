package com.cupitmadland.SMS.jpa.dao;

import java.util.List;

import com.cupitmadland.SMS.jpa.entitymodels.Course;

public interface CourseDAO {
	
	List<Course> getAllCourses();

}
